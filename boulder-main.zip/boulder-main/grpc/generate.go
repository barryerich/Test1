package grpc

//go:generate ./protogen.sh
