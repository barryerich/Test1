# `load-generator`

![](https://i.imgur.com/58ZQjyH.gif)

`load-generator` is a load generator for RFC 8555 which emulates user workflows.
