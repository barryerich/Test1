// This package collects types that are common to both wfe and wfe2.
package web
